﻿using CARS.MODELS;
using System;
using System.Collections.Generic;

namespace CARS.REPOSITORY
{
    internal interface IIncidentRepository
    {
        void CreateIncident(Incident incident);
        void UpdateIncident(int incidentId, string status); 
        void SearchIncident(int incidentId, string incidentType);

        List<Incident> ListIncidentDate(DateTime startDate, DateTime endDate);

        //int GetCaseDetails(int caseId);
        Case GetCaseDetails(int caseId);

        void GenerateIncidentReport(int incidentId);
        void CreateCase(int caseId, string description, int incidentId);
    }
}
