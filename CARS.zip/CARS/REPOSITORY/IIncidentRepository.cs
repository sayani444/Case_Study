﻿using CARS.MODELS;
using Microsoft.Data.SqlClient;
using CARS.UTILITY;
//using System;
//using System.Collections.Generic;

namespace CARS.REPOSITORY
{
    internal class IncidentRepository : IIncidentRepository
    {
        string databaseConnectionString = DBConnUtill.GetConnectionString();
        SqlCommand command = null;

        public IncidentRepository()
        {
            command = new SqlCommand();
        }

        public void CreateIncident(Incident incident)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(databaseConnectionString))
                {
                    connection.Open();
                    command.Connection = connection;
                    command.CommandText = "insert into Incidents values(@IncidentType,@IncidentDate,@Latitude,@Longitude,@Description,@Status,@VictimId,@SuspectId)";
                    command.Parameters.AddWithValue("@IncidentType", incident.IncidentType);
                    command.Parameters.AddWithValue("@IncidentDate", incident.IncidentDate);
                    command.Parameters.AddWithValue("@Latitude", incident.Latitude);
                    command.Parameters.AddWithValue("@Longitude", incident.Longitude);
                    command.Parameters.AddWithValue("@Description", incident.Description);
                    command.Parameters.AddWithValue("@Status", incident.Status);
                    command.Parameters.AddWithValue("@VictimId", incident.VictimId);
                    command.Parameters.AddWithValue("@SuspectId", incident.SuspectId);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        public void UpdateIncident(int incidentId, string status)
        {
            try
            {
                using (SqlConnection sqlconnection = new SqlConnection(databaseConnectionString))
                {
                    command.CommandText = "UPDATE Incident set status = @newstatus where IncidentId = @incidentId";
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@incidentId", incidentId);
                    command.Parameters.AddWithValue("@newstatus", status);

                    sqlconnection.Open();
                    command.Connection = sqlconnection;

                    int UpdateIncident = command.ExecuteNonQuery();

                    if (UpdateIncident > 0)
                    {
                        Console.WriteLine("Incident Successfully Updated");
                    }
                    else
                    {
                        Console.WriteLine("Error. Not Updated Successfully");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        public void SearchIncident(int incidentId, string incidentType)
        {
            try
            {
                using (SqlConnection sqlconnection = new SqlConnection(databaseConnectionString))
                {
                    command.CommandText = "SELECT * FROM Incident Where IncidentType = @incidentType";
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@incidentType", incidentType);

                    sqlconnection.Open();
                    command.Connection = sqlconnection;

                    int SearchIncident = command.ExecuteNonQuery();

                    if (SearchIncident > 0)
                    {
                        Console.WriteLine("Incident Successfully Searched");
                    }
                    else
                    {
                        Console.WriteLine("Error. Not Searched Successfully");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        public List<Incident> ListIncidentDate(DateTime startDate, DateTime endDate)
        {
            List<Incident> incidentList = new List<Incident>();

            try
            {
                using (SqlConnection sqlconnection = new SqlConnection(databaseConnectionString))
                {
                    command.CommandText = "SELECT * FROM Incident Where startDate >= @startDate and endDate <= @endDate";
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@startDate", startDate);
                    command.Parameters.AddWithValue("@endDate", endDate);

                    sqlconnection.Open();
                    command.Connection = sqlconnection;

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Incident incident = new Incident();
                        incident.IncidentId = (int)reader["incidentId"];
                        // Populate other properties as needed
                        incidentList.Add(incident);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            return incidentList;
        }

        public void SearchIncidentType(string type)
        {
            try
            {
                using (SqlConnection sqlconnection = new SqlConnection(databaseConnectionString))
                {
                    command.CommandText = "SELECT * FROM Incident Where IncidentType = @incidentType";
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@incidentType", type);

                    sqlconnection.Open();
                    command.Connection = sqlconnection;

                    int returnIncidentType = command.ExecuteNonQuery();

                    if (returnIncidentType > 0)
                    {
                        Console.WriteLine("Type returned successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Type not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        public void GenerateIncidentReport(int incidentId)
        {
            try
            {
                using (SqlConnection sqlconnection = new SqlConnection(databaseConnectionString))
                {
                    command.CommandText = "SELECT * From Reports Where IncidentId = @incidentId";
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@incidentId", incidentId);

                    sqlconnection.Open();
                    command.Connection = sqlconnection;

                    int returnReportStatus = command.ExecuteNonQuery();

                    if (returnReportStatus > 0)
                    {
                        Console.WriteLine("Report returned successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Report not found or already returned.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        public void CreateCase(int caseId, string description, int incidentId)
        {
            try
            {
                using (SqlConnection sqlconnection = new SqlConnection(databaseConnectionString))
                {
                    sqlconnection.Open();

                    command.CommandText = "INSERT INTO Case VALUES(@caseId,@description,@incidentId)";
                    command.Connection = sqlconnection;
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@caseId", caseId);
                    command.Parameters.AddWithValue("@description", description);
                    command.Parameters.AddWithValue("@incidentId", incidentId);

                    int addCaseStatus = command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
        public void CreatingCase(int caseId, string description, int incidentId)
        {
            try
            {
                using (SqlConnection sqlconnection = new SqlConnection(databaseConnectionString))
                {
                    sqlconnection.Open();

                    command.CommandText = "INSERT INTO Case VALUES(@caseId,@description,@incidentId)";
                    command.Connection = sqlconnection;
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@caseId", caseId);
                    command.Parameters.AddWithValue("@description", description);
                    command.Parameters.AddWithValue("@incidentId", incidentId);

                    int addCaseStatus = command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
        public Case GetCaseDetails(int caseId)
        {


        try
            {
                using (SqlConnection sqlconnection = new SqlConnection(databaseConnectionString))
                {
                    command.CommandText = "SELECT * FROM Case WHERE CaseId = @caseId";
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@caseId", caseId);
                    sqlconnection.Open();
                    command.Connection = sqlconnection;

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                       Case caseDetails = new Case()
                        {
                            CaseId = (int)reader["CaseId"],
                            Description = reader["Description"].ToString(),
                            // Populate other properties as needed
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
            return GetCaseDetails(caseId);
           
        }




        }
    }
