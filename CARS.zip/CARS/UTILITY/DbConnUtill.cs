﻿using Microsoft.Extensions.Configuration;
using System.IO;

namespace CARS.UTILITY
{
    internal class DBConnUtill
    {
        private static IConfiguration _iConfiguration;

        public static string GetConnectionString()
        {
            try
            {
                if (_iConfiguration == null)
                {
                    GetAppSettingsFile(); // Ensure configuration is loaded
                }

                return _iConfiguration.GetConnectionString("LocalConnString");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while retrieving the connection string: {ex.Message}");
                return null;
            }
        }

        private static void GetAppSettingsFile()
        {
            try
            {
                var builder = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json");

                _iConfiguration = builder.Build();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while loading appsettings.json: {ex.Message}");
            }
        }
    }
}
