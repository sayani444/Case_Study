﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CARS.MODELS
{
    internal class Case
    {
        private int caseId;
        private string description;
        private int incidentId;

        public Case() { }

        public Case(int caseId, string description, int incidentId)
        {
            CaseId = caseId;
            Description = description;
            IncidentId = incidentId;
        }

        public int CaseId
        {
            get { return caseId; }
            set { caseId = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        public int IncidentId
        {
            get { return incidentId; }
            set { incidentId = value; }
        }
    }
}
