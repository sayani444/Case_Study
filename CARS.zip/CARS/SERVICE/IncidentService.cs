﻿using CARS.MODELS;
using CARS.REPOSITORY;
using CARS.UTILITY;
using Microsoft.Extensions.Configuration;
using System;
using System.Data.SqlClient;

namespace CARS.SERVICE
{
    internal class IncidentService : IIncidentService
    {
        private readonly IIncidentRepository _incidentRepository;
        private readonly DBConnUtil _dbConnUtil;

        public IncidentService(IIncidentRepository incidentRepository)
        {
            IncidentRepository = incidentRepository;
        }

        public IncidentService(IIncidentRepository incidentRepository, IConfiguration configuration)
        {
            _incidentRepository = incidentRepository;
            _dbConnUtil = new DBConnUtil(configuration);
        }

        public IIncidentRepository IncidentRepository { get; }

        // ... rest of your existing code ...

        private SqlConnection GetConnection()
        {
            return _dbConnUtil.GetDBConnection();
        }
    }
}
