﻿using CARS.MODELS;
using System;

namespace CARS.SERVICE
{
    internal interface IIncidentService
    {
        void CreateIncident();
        void UpdateIncident();
        void SearchIncident();
        void GenerateIncidentReport();
        Case GetCaseDetails(int caseId);
    }
}

