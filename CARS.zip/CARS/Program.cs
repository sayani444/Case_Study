﻿using CARS.REPOSITORY;
using CARS.MODELS;
using System;
using CARS.SERVICE;

namespace CARS
{
    internal class Program
    {
        static void Main(string[] args)
        {

            IIncidentRepository incidentRepository = new IncidentRepository();


            IIncidentService incidentService = new IncidentService(incidentRepository);


            //incidentService.CreateIncident();
            // incidentService.UpdateIncident();
            //incidentService.SearchIncident();
            // incidentService.GenerateIncidentReport();
            Console.WriteLine("Enter CaseId:");
            int caseIdInput = int.Parse(Console.ReadLine());

            incidentService.GetCaseDetails(caseIdInput);



        }
    }
}